#include <stdio.h>
#include <windows.h>

typedef struct date
{
	unsigned int year;
	unsigned int month;
	unsigned int day;
}D_A_T_E_;
typedef struct time 
{
	unsigned int    hour;
	unsigned int  minute;
	unsigned int  second;
}TIME;
void next_date_func(D_A_T_E_ * num1);

int main()
{

	D_A_T_E_ num1,*p=&num1;
	TIME now_time;
	printf("�����뵱ǰ�����ڣ���2010 10 20\n");
	printf("----------------------------------\n");
	scanf("%d %d %d",&num1.year ,&num1.month,&num1.day);
	printf("----------------------------------\n");
	printf("�����뵱ǰ��ʱ�䣺��14:25:35\n");
	printf("----------------------------------\n");
	scanf("%d %d %d",&now_time.hour ,&now_time.minute,&now_time.second);
	printf("----------------------------------\n");
	printf("��ǰʱ�䣺%d��%02d��%02d��   %02d:%02d:%02d\n",num1.year,num1.month,num1.day,\
	          now_time.hour,now_time.minute,now_time.second);
	while(1)
	{ 
	    Sleep(880);
	    now_time.second++;
		if(now_time.second==60)
		{
			now_time.second=0;
			now_time.minute++;
			if(now_time.minute==60)
			{
				now_time.minute=0;
				now_time.hour++;
				if(now_time.hour==24)
				{
					now_time.hour=0;
			    	next_date_func(p);
				}
			}
		}
		system("cls");
		printf("��ǰʱ�䣺%d��%02d��%02d��   %02d:%02d:%02d\n",num1.year,num1.month,num1.day,\
	          now_time.hour,now_time.minute,now_time.second);
		
	}
	return 0;
	
 } 
 void next_date_func(D_A_T_E_ * num1)
{
	unsigned int end=0;
	switch(num1->month)
	{  
	    case 12:end=31;break;
		case 11:end=30;break;
		case 10:end=31;break;
		case  9:end=30;break;
		case  8:end=31;break;
		case  7:end=31;break;
		case  6:end=30;break;
		case  5:end=31;break;
		case  4:end=30;break;
		case  3:end=31;break;
		case  2: if((num1->year%4==0&&num1->year%100!=0) || num1->year%400==0)
		        {
		            end=29;break;
				}   
			    else 
				{ 
				    end=28;break;	
				}
		case  1:end=31;break;
		default: break;
	}
	if(num1->day==end)
	{
		if(num1->month==12)
		{
			num1->year++;
			num1->month=1;
			num1->day=1;
		}
		else
		{
			num1->month++;
			num1->day=1;
		}
	}
	else num1->day++;
	return ;
}

