#include <iostream>
int  main(void)
{	
	using namespace std;
	cout<< "come out and C++";
	cout<< endl;
	cout<< "you won't regret it!"<< endl;
	return 0;
	 
}
















