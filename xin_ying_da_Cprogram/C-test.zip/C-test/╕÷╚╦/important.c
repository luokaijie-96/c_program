#include <stdio.h>
int main(void)
{
	int number[3][5] = {1,2,3,4,5,6,7,8,9,0,0,9,8,7,6};
	int (*pnumber)[5] = number;//û����
	//printf("  %d\n",*((*pnumber)++)  );
	printf("  %d\n",(*(*pnumber))++ );
	
	return 0;
}
//����ָ��   *ָ��