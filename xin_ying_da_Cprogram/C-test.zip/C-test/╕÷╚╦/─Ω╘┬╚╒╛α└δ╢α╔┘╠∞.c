#include <stdio.h>  //1970 01 01
int main(void)
{
	unsigned int year,month,day,sum=0,i=0; 
	unsigned short extra=0;
	
	int calendar[42]={0};

		printf("���������:");
     	scanf("%u",&year);
	    printf("�������·�:");
	    scanf("%u",&month);
	    printf("�����뼸��:");
	    scanf("%u",&day);
    
        switch(month-1) 
	    {
	    case 11: sum+=30;
		case 10: sum+=31;
		case  9: sum+=30;
		case  8: sum+=31;
        case  7: sum+=31;
		case  6: sum+=30;
        case  5: sum+=31;
		case  4: sum+=30;
		case  3: sum+=31;
		case  2: sum+=28;
		case  1: sum+=31;
		default: sum+=0;

	    }

	    for(i=1970;i<year;i++)
	    {
		    if( ((i%4==0)&&(i%100!=0))||(i%400==0) )
			extra++;
	    }

	    if( ((i%4==0)&&(i%100!=0))||(i%400==0))
	    {
		    if(month-1>=2)
			extra++;
	    }

	    sum+=(year-1970)*365+extra+(day-1);
	    printf("---------------------------------\n");
	    printf("����1970.01.01��%u��\n",sum);
        printf("\n---------------------------------\n");
	return 0;
	
}
