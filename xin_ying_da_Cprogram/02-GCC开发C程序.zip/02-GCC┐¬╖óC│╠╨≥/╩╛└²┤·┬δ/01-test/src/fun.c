
#include "../inc/fun.h"

#include <stdio.h>

int add(int a,int b)
{
	return a+b;
}

 
int sub(int a,int b)
{
	int r;
	r = a-b;
	printf("1");
	printf("2");
	printf("3");
	
	return r;
}

