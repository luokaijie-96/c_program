#include <stdio.h>
#include <stdlib.h>
#include "../inc/fun.h"

/* run this program using the console pauser or add your own getch,
 system("pause") or input loop */
int main(int argc, char *argv[]) 
{
	int s =0;
	s = add(1,2);
	printf("add(1,2):%d\r\n",s);
	s = sub(2,1);
	printf("sub(2,1):%d\r\n",s);	
	return 0;
}




 


